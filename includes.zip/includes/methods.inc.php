<?php
    
    class methods {
        function addRecipeSeller($name, $surname, $phone_number, $companyName, $email, $address, $profile_picture, $password){
            require 'includes/dbcon.inc.php';
            require 'includes/existing.php';
            require 'error.php';
            $exist = new checkExistanceOfValuesInDB();
            $msg = new message();

            try {
                
                if ($exist -> isExisting ($email) == false) {
                    $sql = " INSERT INTO `recipe-chef` (`name`, `surname`, `pno`, `emailAddress`, `companyifApplicable`, `address`, `profile_picture`, `password`)
                    VALUES ('".$name."', '".$surname."', '".$phone_number."', '".$email."', '".$companyName."', '".$address."', '".$profile_picture."', '".$password."');";
    
                    $results = mysqli_query($conn, $sql);
                    if ($results == true){
                        $msg -> errorMessage(" Record Add Successfully !!! ", "index.php");
                    }
                    else {
                        $error =  " An error occured " .$conn -> error;
                        $msg -> errorMessage($error, "index.php");
                    }
                }
                else {
                    $error = " This email ". $email. "  already registered with us !!!";
                    $msg -> errorMessage($error, "index.php");
                }

            } catch (\Throwable $th) {
                echo $th;
            }
        }
        function login($email, $password){
            require 'includes/dbcon.inc.php';
            //require 'includes/existing.php';
            require 'error.php';
            ?>
                <script> alert ('This is working');</script>
            <?

            // $sql = " SELECT * FROM `recipe-chef` WHERE emailAddress = '".$email."' and password = '".$password."';";
            // $results = mysqli_query($conn, $sql);
            // $resultCheck = mysqli_num_rows($results);
            // if ($resultCheck <= 0) {
            //     session_start();
            //     $_SESSION['email'] = $email;
            //     header("location: seller.panel.php");
            // }
            // else {
            //     $error = " Incorrect password / credentials";
            //     // $msg = new message();
            //     // $msg -> errorMessage($error, "home-header.php");
            //     ?>
            //         <!-- <script> alert (" Error ")</script> -->
            //     <?php
            // }
        }
        function errors($error){
            ?>
                <div class="container" id="popup">
                    <span style="color: red; text-align: center; top: 50%; left: 50%;" id="errorMessage"><strong><?php echo $error?></strong></span>
                </div>
            <?php
        }   
        //image function
        function uploadImage($image){
            //if(isset($_POST['add']) && isset($_FILES['image'])){

                $img_name = $_FILES['profile']['name'];
                $img_size = $_FILES['profile']['size'];
                $temp_name = $_FILES['profile']['tmp_name'];
                $error = $_FILES['profile']['error'];
        
                if ($error === 0) {
                    # code...
                    if ($img_size > 125000) {
                        # code...
                        $message = "Your file is to big";
                        errors($message);
                    }else {
                        $img_ext = pathinfo($img_name, PATHINFO_EXTENSION);
                        //echo $img_ext;
                        $img_ext_lc = strtolower($img_ext);
            
                        $allowed_exs = array('jpg', 'jpeg', 'png');
                        if (in_array($img_ext_lc, $allowed_exs)) {
                            # code...
                            $new_img_name =uniqid("IMG-", true).".".$img_ext_lc;
                            $img_upload_path = 'uploads/'.$new_img_name;
                            move_uploaded_file($temp_name, $img_upload_path);
            
                        }else {
                            $message = " File you are picture not allowed";
                            errors($message);
                        }
                    }
                }else {
                    $message = " Can't locate file !!!"; 
                    errors($message);
                }
            //}
        }
        function selectMyRecipes($username){
            require 'includes/dbcon.inc.php';

            $sql = "SELECT * from recipe where emailAddress = '".$username."' order by recipeName asc;";
            $result = mysqli_query($conn, $sql);
            $resultCheck = mysqli_num_rows($result);

            if($resultCheck <= 0){
                ?>
                    <h3 style="color: red; text-align: center; padding: 40px;"> No Data Found !!! <br>

                        Add you recipe <a href="add-new-recipe.php">here</a> and make money out of it. They system will charger <strong><em>16%</em></strong> of your recipe !!! 
                    </h3>
                <?php
            }
            else {
                ?>
                    <style>
                        p{
                            background-color: white;
                            width: 100%;
                            color: #000000;
                            border-radius: 10px;
                            text-justify: justify;
                        }
                    </style>
                    <p style=" text-align: center; padding: 40px;"> 
                        List of recipes found on your account, Keep on adding new recipes to generate income. <br>
                        Let your recipes prepared by you as finest cook in Africa make you rich. 
                        They system will charger <strong><em>16%</em></strong> of your recipe !!! 
                    </p>
                <?php
                while($row = mysqli_fetch_assoc($result)){
                    //cho $row['image'];
                    ?>
                        <style>
                            .recipe img, .recipe2 img, .recipe3 img, .recipe4 img{
                                width:100%;
                                height: 200px;
                            }
                            .recipe, .recipe2, .recipe3, .recipe4{
                                float: left;
                                width: 20%;
                                margin: 30px;
                                border-radius: 10px;
                                /* border: 1px solid red; */
                            }
                            .purchase-details {
                                height: auto;
                            }
                            #description{
                                padding: 10px;
                                width: auto;
                                font-size: 0.8em;
                                line-height: normal; 
                                border-radius: none; 
                                background-color: white;
                                color: black;                      

                            }
                        </style>
                        <!-- <div class="container"> -->
                            <div class="purchase-details" style="border-radius: 5px;">
                                <div class="recipe" >
                                    <!-- <img src="recipe-pics/<?=$row['image']?>"> -->
                                    <img src="recipe-pics/<?=$row['image']?>" alt="">
                                    <br>
                                    <div class="description">
                                        <h5> <?php echo $row['recipeName'];?></h5>
                                        <textarea id="description" rows= "3" style="width: 100%;" disabled><?php echo $row['description'];?></textarea>

                                        <center>
                                            <span style="color: red;"><em>LSL <?php echo $row['price'];?></em></span>
                                            <br>
                                            <!-- <button> Manage Here </button> -->
                                        </center>
                                        <span>
                                            <a href="recipe-book.php?recipe=<?php echo $row['recipeName']?>">Details</a> | Modify | Delete | Report
                                        </span>                                    
                                    </div>
                                </div>
                            </div>
                        <!-- </div> -->
                    <?php
                }
            }
        }
        function selectAllRecipesFromDB(){
            require 'includes/dbcon.inc.php';

            $sql = " SELECT * from recipe ORDER BY price asc;";
            $result = mysqli_query($conn, $sql);
            $resultCheck = mysqli_num_rows($result);

            if($resultCheck <= 0){
                ?>
                    <h3 style="color: red; text-align: center; padding: 40px;"> No Data Found !!! <br>

                        <!-- Add you recipe <a href="#">here</a> and make money out of it. They system will charger <strong><em>16%</em></strong> of your recipe !!!  -->
                    </h3>
                <?php
            }
            else {
                ?>
                    <style>
                        p{
                            background-color: #04AA6D;
                            width: 100%;
                            color: #ffffff;
                            border-radius: 10px;
                            text-justify: justify;
                        }
                    </style>
                    <!-- <p style=" text-align: center; padding: 40px;"> 
                        List of recipes found on your account, Keep on adding new recipes to generate income. <br>
                        Let your recipes prepared by you as finest cook in Africa make you rich. 
                        They system will charger <strong><em>16%</em></strong> of your recipe !!! 
                    </p> -->
                <?php
                while($row = mysqli_fetch_assoc($result)){
                    ?>
                        <style>
                            .recipe img, .recipe2 img, .recipe3 img, .recipe4 img{
                                width:100%;
                                height: 200px;
                            }
                            .recipe, .recipe2, .recipe3, .recipe4{
                                float: left;
                                width: 20%;
                                margin: 30px;
                                border-radius: 10px;
                                /* border: 1px solid red; */
                            }
                            .purchase-details {
                                height: auto;
                            }
                            #description{
                                padding: 10px;
                                width: auto;
                                font-size: 0.8em;
                                line-height: normal; 
                                border-radius: none; 
                                background-color: white;
                                color: black;                      

                            }
                        </style>
                        <!-- <div class="container"> -->
                            <div class="purchase-details">
                                <div class="recipe">

                                    <img src="recipe-pics/<?=$row['image']?>">
                                    <br>
                                    <div class="description">
                                        <?php 

                                        ?>
                                        <h5 name="recipeName"> <?php echo $row['recipeName'];?></h5>
                                        <p id="description"><?php echo $row['description'];?></p>      
                                                                       
                                        <center>
                                            <span style="color: red;"><em>LSL <?php echo $row['price'];?></em></span>
                                            <br>
                                            <br>
                                            <a class="btn btn-primary btn-sm" href="order.php?editid=<?=$row['recipeName'];?>">Add to Cart </a>
                                        </center>
                                    </div>
                                </div>
                            </div>
                        <!-- </div> -->
                    <?php
                }
            }
        }
        function  uploadRecipeSellerImage($img_name, $img_size, $temp_name, $error, $new_img_name){
            if ($error === 0) {
                # code...
                if ($img_size > 500000) {
                    # code...
                    echo "Your file is to big";
                }else {
                    $img_ext = pathinfo($img_name, PATHINFO_EXTENSION);
                    //echo $img_ext;
                    $img_ext_lc = strtolower($img_ext);
        
                    $allowed_exs = array('jpg', 'jpeg', 'png');
                    if (in_array($img_ext_lc, $allowed_exs)) {
                        # code...
                        $new_img_name =uniqid("IMG-", true).".".$img_ext_lc;
                        $img_upload_path = 'recipe-seller-profiles-pics/'.$new_img_name;
                        move_uploaded_file($temp_name, $img_upload_path);

                        
        
                    }else {
                        echo "File not allowed";
                    }
                }
            }else {
                echo " An error occured !!!"; 
            }
        }
        function  uploadRecipeImage($img_name, $img_size, $temp_name, $error, $new_img_name){
            if ($error === 0) {
                # code...
                if ($img_size > 125000) {
                    # code...
                    echo "Your file is to big";
                }else {
                    $img_ext = pathinfo($img_name, PATHINFO_EXTENSION);
                    //echo $img_ext;
                    $img_ext_lc = strtolower($img_ext);
        
                    $allowed_exs = array('jpg', 'jpeg', 'png');
                    if (in_array($img_ext_lc, $allowed_exs)) {
                        # code...
                        $new_img_name =uniqid("IMG-", true).".".$img_ext_lc;
                        $img_upload_path = 'recipe-pics/'.$new_img_name;
                        move_uploaded_file($temp_name, $img_upload_path);

                        
        
                    }else {
                        echo "File not allowed";
                    }
                }
            }else {
                echo " An error occured !!!"; 
            }
        }
        function addRecipe($recipeName, $price, $username, $new_img_name, $description, $cookingMethod){
            require 'includes/dbcon.inc.php';
            require 'includes/existing.php';
            require 'success.php';
            //require 'error.php';
            $exist = new checkExistanceOfValuesInDB();
            $msg = new message();
            $success = new successfulAndStaysAtSafeFIle();

            try {
                
                if ($exist -> existingRecipe($recipeName) == false) {

                    $sql = "INSERT INTO `recipe` (`recipeName`, `price`, `emailAddress`, `image`, `description`, `cooking_method`) 
                    values ('".$recipeName."', '".$price."', '".$username."', '".$new_img_name."', '".$description."', '".$cookingMethod."')";
                    $results = mysqli_query($conn, $sql);
                    if ($results == true){
                        $confirm = " Your recipe, " .$recipeName ." recorded sucessfully ";
                        //$success -> addIngriedents($confirm);
                    }
                    else {
                        $error =  " An error occured " .$conn -> error;
                        $success -> errorMessage($error);
                    }
                }
                else {
                    $error = " This recipe ".$recipeName."  already added into the system !!!";
                    $success -> errorMessage($error);
                }

            } catch (\Throwable $th) {
                echo $th;
            }
        }
        function addRecipeIngredient($recipeName, $ingredientName, $measurement){
            require 'includes/dbcon.inc.php';
            require 'includes/existing.php';
            require 'success.php';
            //require 'error.php';
            $msg = new message();
            $success = new successfulAndStaysAtSafeFIle();

            try {
                
                //if ($exist -> existingRecipe($recipeName) == false) {

                $sql = "INSERT INTO `ingredients` (`ingredientID`, `ingredeintName`, `measurement`, `recipeName`) 
                VALUES (NULL, '".$ingredientName."', '".$measurement."', '".$recipeName."');";
                $results = mysqli_query($conn, $sql);
                if ($results == true){
                    $confirm = " You have added " .$ingredientName ." ingredient to your " .$recipeName. " sucessfully ";
                    $success -> addTypicalNutrition($confirm);
                }
                else {
                    $error =  " An error occured " .$conn -> error;
                    $success -> errorMessage($error);
                }


            } catch (\Throwable $th) {
                echo $th;
            }
        }
        function addRecipeTypicalNutrietion($nutrietion, $servingPer100ml, $servingPer20ml, $recipeName){
            require 'includes/dbcon.inc.php';
            require 'includes/existing.php';
            require 'success.php';
            //require 'error.php';
            $msg = new message();
            $success = new successfulAndStaysAtSafeFIle();

            try {
                
                //if ($exist -> existingRecipe($recipeName) == false) {

                $sql = "INSERT INTO `typicalnutrition` (`nutrient`, `serving per 100ml`, `serving per 20ml`, `recipeName`) 
                VALUES ('".$nutrietion."', '".$servingPer100ml."', '".$servingPer20ml."', '".$recipeName."');";
                $results = mysqli_query($conn, $sql);
                if ($results == true){
                    $confirm = " You have added " .$nutrietion ." nutrient to your " .$recipeName. " sucessfully ";
                    $success -> errorMessage($confirm);
                }
                else {
                    $error =  " An error occured " .$conn -> error;
                    $success -> errorMessage($error);
                }


            } catch (\Throwable $th) {
                echo $th;
            }
        }
        function addOrder($name, $surname, $email, $pno, $recipeName){
            require 'includes/dbcon.inc.php';
            //require 'includes/existing.php';
            require 'success.php';
            $success = new successfulAndStaysAtSafeFIle();
            try {
                $sql = "INSERT INTO `recipeorder` (`orderid`, `name`, `surname`, `email`, `pno`, `recipeName`) 
                VALUES (NULL, '".$name."', '".$surname."', '".$email."', '".$pno."', '".$recipeName."');";
                
                $results = mysqli_query($conn, $sql);
                if ($results == true){
                    $confirm = " You have place an order on " .$recipeName;
                    $success -> errorMessage($confirm);
                }
                else {
                    $error =  " An error occured " .$conn -> error;
                    $success -> errorMessage($error);
                }

            } catch (\Throwable $th) {
                echo $th;
            }
        }
        function orderOnMyRecipe($username){
            require 'includes/dbcon.inc.php;';
            try {
                $sql = " select";
            } catch (\Throwable $th) {
                //throw $th;
            }
        }

        //get recipe seller details 
        function generateRecipeContent($username, $recipeName){
            require 'includes/dbcon.inc.php';

            $recipeSellerName = "";
            $rN = $recipeName;
            $recipeSellerSurname = "";

            //get recipe seller
            $sql = " SELECT * FROM `recipe-chef` inner join recipe on `recipe-chef`.`emailAddress` = recipe.emailAddress 
                    WHERE `recipe-chef`.emailAddress ='".$username."';";
            $results = mysqli_query($conn, $sql);
            //$results = mysqli_query($conn, $sql);
            $resultCheck = mysqli_num_rows($results);

            if($resultCheck <= 0){
                
            }else {
                while ($row = mysqli_fetch_assoc($results)){
                    $name = $row['name'];
                    $surname = $row['surname'];
                    $pno = $row['pno'];
                    $emailAddress = $row['emailAddress'];
                    $companyIfApplicable = $row['companyifApplicable'];
                    $address = $row['address'];
                    $profile_picture = $row['profile_picture'];

                    ?>
                        <div class="container">
                            <center>
                                <h1>Buy and sell your recipe on this system</h1>
                                <h3> <u>Recipe Seller Details</u> </h3>
                                <h5> <?php echo $recipeSellerName = $name." ".$recipeSellerSurname = $surname. " | " .$rN;?></h5>
                            </center>
                            <hr color="black">
                            <div class="recipeSeller">
                                <img src="recipe-seller-profiles-pics/<?=$profile_picture?>" alt=" Picture" width="100%" height="200px">
                                <br>
                                <br>
                                <input type="text" name="" id="" value="<?php echo $name ." ".$surname." ".$pno. " ".$emailAddress." ".$companyIfApplicable." ".$address?>" disabled class="form-control">
                                <hr color="black"> 
                            </div>
                        </div>
                    <?php
                }
            }
            
            //get recipe
            $sql = " SELECT * from recipe where recipeName = '".$recipeName."';";
            $results = mysqli_query ($conn, $sql);
            $resultCheck = mysqli_num_rows($results);

            if ($resultCheck <= 0){
                echo "no results found";
            }else{
                while ($row = mysqli_fetch_assoc($results)) {
                    ?>
                        <div class="container">

                            <center> 
                                <h3> <u>Recipe Seller Details</u> </h3>
                                <H4> <?php echo $recipeName?> details</H5>
                            </center>
                            <img src="recipe-pics/<?=$row['image']?>" alt=" Picture" width="100%" height="200px">
                            <br><br>
                            <strong>Description</strong>
                            <textarea name="" id="" rows="5" style="width: 100%;" class="form-control" disabled > <?php echo $recipeName. " | LSL" .$row['price']." ".$row['description'];?></textarea>
                            <strong>Cooking Method</strong>
                            <textarea name="" id="" style="width: 100%;" class="form-control" disabled> <?php echo $row['cooking_method']?></textarea>
                            <hr color="black">
                        </div>
                        
                    <?php
                }
            }

            ?>
                <br>
                <center>
                    <h4> 🎂 End of <em><?php echo $recipeName;?></em> recipe book prepared by <?php echo $name." ".$surname;?> 🎂 </h4>
                    <h5> 🍦 Thank you for your corporation 🍦 </h5>
                </center>

                <br>
                <br><br>
            <?php
        }
        //number of recipes per recipe seller
        function numberOfRecipiesPerSeller($username){
            require 'includes/dbcon.inc.php';
            $recipeNumber = 0;
            try {
                $sql = "SELECT COUNT(recipeName) as 'NumberofRecipes' from recipe where emailAddress = '".$username."';";
                $result = mysqli_query($conn, $sql);
                $resultCheck = mysqli_num_rows($result);

                if($resultCheck <= 0){
                    $recipeNumber =  0;
                }
                else {
                    while ($row = mysqli_fetch_assoc($result)) {
                        return $row['NumberofRecipes'];
                    }
                }
            } catch (\Throwable $th) {
                echo $th;
            }
        }
    }
?>