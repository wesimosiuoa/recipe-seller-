<?php 
    class checkExistanceOfValuesInDB{ 
        function isExisting ($existingVariable){
            require 'includes/dbcon.inc.php';
            $existing = true;
            // $exists = false;
            $sql = " SELECT * FROM `recipe-chef` where `emailAddress` = '".$existingVariable."';";
            $results = mysqli_query($conn, $sql);
            $resultCheck = mysqli_num_rows($results);
            if ($resultCheck <= 0){
                $existing = false;
            }
            return $existing; 
        }
        function existingRecipe($existRecipe){
            require 'includes/dbcon.inc.php';
            $existing = true;
            // $exists = false;
            $sql = " SELECT * FROM `recipe` where `recipeName` = '".$existRecipe."';";
            $results = mysqli_query($conn, $sql);
            $resultCheck = mysqli_num_rows($results);
            if ($resultCheck <= 0){
                $existing = false;
            }
            return $existing; 
        }
    }
?>