function openRegistration(){
    document.getElementById("body").style.display = "none";
    document.getElementById("sign").style.display = "none";
    document.getElementById("my-register").style.display = "block";
    document.getElementById("arrow").style.display = "none";
}
function closeMyRegister(){
    document.getElementById("msg").style.display = "none";

}
function openMyRegister(){
    document.getElementById("msg").style.display = "block";

}
function closeIndexBody(){
    
}
function openabout(){
    document.getElementById("about").style.display = "block";
}

function closeabout(){
    document.getElementById("about").style.display = "none";
}

function opensign(){
    document.getElementById("sign").style.display = "block";
}

function closesign(){
    document.getElementById("sign").style.display = "none";
}

function opencontact(){
    document.getElementById("contact").style.display = "block";
}

function closecontact(){
    document.getElementById("contact").style.display = "none";
}
function fieldsValidatation(){
    
}
function noDataFound(){
    alert (" This is where you will add you recipe !!! ");
}